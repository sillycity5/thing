# Jarbel Menu

A hand menu mod for Yeeps (blaze build), built on the starter menu's layout.

## Build

1. Install the Android NDK **r27c**, CMake 3.22+, Ninja and Python 3.
2. From the repo root: `ANDROID_NDK=/path/to/android-ndk-r27c bash build.sh`
3. Output: `out/jarbel-menu.so`

Only `mods/jarbel-menu/` is changed from the official repo. From the repo root,
`python3 tools/verify_repo.py` should still print `OK`.

## Install

Move `out/jarbel-menu.so` into `Android/data/com.TrassGames.Yeeps/files/mods/`
on the headset and restart Yeeps. If your file explorer can't open `Android/data`,
use SideQuest from a PC.

## Controls

- Hold **Y** (left hand) for the menu; press buttons with your right index finger.
- **<** and **>** switch pages.
- Pages: Movement Mods, Rig Mods, Items, Item Picker, Settings, Enabled Mods.

## Fling Gun

Movement Mods -> Fling Gun. Hold right grip to aim, press right trigger to launch
yourself along the direction your hand points (+6 m/s of lift, 0.4 s cooldown).
Settings -> Fling Power cycles 12 / 20 / 32 m/s (default 20). It only moves your own
body, through the game's own velocity functions.

## Item Picker

Items -> Item Picker. Keys are learned from the room's loaded Item objects (scanned
once per room, and by "Scan Room For Items") and from the item in your left hand
("Set Item From Hand"), so no key list is guessed. Tap a key to use it for Spawn On
Hand, Spawn Item Gun and both Duplicate buttons; tap the same key again to go back to
using whatever is in your left hand. The title shows the current pick while the
picker page is open.

## Limits

Movement mods only change your own game. Rig mods move your own hands (everyone sees
the pose). Item spawning goes through the game's own `RpcCreateItem` with a cooldown on
every button, at most 2 items a frame and at most 32 queued.
